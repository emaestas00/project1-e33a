from django.urls import path
from . import views

# URL Pattern for Entry Page
urlpatterns = [
    path("", views.index, name="index"),
    path("wiki/<str:title>/", views.entry, name="entry"),
    path("search/", views.search, name="search"),  
]

# URL Pattern for Search Route
urlpatterns = [
    path("", views.index, name="index"),
    path("wiki/<str:title>/", views.entry, name="entry"),
    path("search/", views.search, name="search"),  
]

# URL Pattern for New Page
urlpatterns = [
    path("", views.index, name="index"),
    path("wiki/<str:title>/", views.entry, name="entry"),
    path("search/", views.search, name="search"),
    path("new/", views.new_page, name="new_page"), 
]

# URL Pattern for Editing Pages
urlpatterns = [
    path("", views.index, name="index"),
    path("wiki/<str:title>/", views.entry, name="entry"),
    path("search/", views.search, name="search"),
    path("new/", views.new_page, name="new_page"),
    path("wiki/<str:title>/edit/", views.edit_page, name="edit_page"),  
]

#URL Pattern for Random Page
urlpatterns = [
    path("", views.index, name="index"),
    path("wiki/<str:title>/", views.entry, name="entry"),
    path("search/", views.search, name="search"),
    path("new/", views.new_page, name="new_page"),
    path("wiki/<str:title>/edit/", views.edit_page, name="edit_page"),
    path("random/", views.random_page, name="random_page"), 
]

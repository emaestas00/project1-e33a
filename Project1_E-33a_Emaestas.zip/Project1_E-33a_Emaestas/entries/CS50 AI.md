# CS50 AI
This is a great tool to help with your debugging. You can ask it to write testing scripts.
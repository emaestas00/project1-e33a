from django.test import TestCase
from encyclopedia import util 

class EncyclopediaTests(TestCase):

    def test_entry_exists(self):
        """Test if retrieving an existing entry returns content"""
        content = util.get_entry("Python")
        self.assertIsNotNone(content)  

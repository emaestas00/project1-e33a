from django.shortcuts import redirect, render
import markdown2
import random
from . import util

# View for Entry Page
def entry(request, title):
    content = util.get_entry(title) 
    if content is None:
        return render(request, "encyclopedia/error.html", {
            "message": "The requested page was not found."
        }) 
    
    # Markdown file name 
    filename = f"{title}.md"

    # Convert Markdown content to HTML
    html_content = markdown2.markdown(content)
    return render(request, "encyclopedia/entry.html", {
        "title": title,
        "filename": filename,
        "content": html_content  
    })

# Get the list of entries and render the index page
def index(request):
    return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries()
    })

# Search for a query in the list of entries
def search(request):
    query = request.GET.get("q", "").strip()
    
    # Retrieve the list of all encyclopedia entries
    entries = util.list_entries()
    
    # Look for an exact match 
    exact_match = next((entry for entry in entries if entry.lower() == query.lower()), None)
    if exact_match:
        # Redirect to the exact entry page if found
        return redirect("entry", title=exact_match)

    # Find all entries that contain the query as a substring (case-insensitive)
    matches = [entry for entry in entries if query.lower() in entry.lower()]

    # Render the search results page with the query and list of matching entries
    return render(request, "encyclopedia/searchresults.html", {
        "query": query,
        "matches": matches 
    })

# Create a new page
def new_page(request):
    if request.method == "POST":
        title = request.POST.get("title").strip()
        content = request.POST.get("content").strip()

        existing_entry = util.get_entry(title)
        if existing_entry is not None:
            return render(request, "encyclopedia/new_page.html", {
                "error": "An entry with this title already exists.",
                "title": title,
                "content": content
            })

        util.save_entry(title, content)  
        return redirect("entry", title=title) 

    return render(request, "encyclopedia/new_page.html") 

# Edit an existing page
def edit_page(request, title):
    if request.method == "POST":
        updated_content = request.POST.get("content").strip()

        util.save_entry(title, updated_content) 
        return redirect("entry", title=title) 

    content = util.get_entry(title)
    if content is None:
        return render(request, "encyclopedia/error.html", {
            "message": "The requested page was not found."
        })

    return render(request, "encyclopedia/edit_page.html", {
        "title": title,
        "content": content  # Show original Markdown content for editing
    })

# Random Page
def random_page(request):
    entries = util.list_entries() 
    if not entries:
        return redirect("index")  

    random_title = random.choice(entries)  
    return redirect("entry", title=random_title)  
